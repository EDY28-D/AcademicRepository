using Microsoft.EntityFrameworkCore;
using Proyect.Models;
using Proyect.EFCore;
var builder = WebApplication.CreateBuilder(args);
builder.Services.DependencyEF();
// Add services to the container.
builder.Services.AddControllersWithViews();
//builder.Services.AddDbContext<SeguimientoCurricularContext>(optionsBuilder =>
//{ 
//       optionsBuilder.
//       UseSqlServer("server=DESKTOP-IVLDN19;database=SeguimientoCurricular;Integrated Security=True;Encrypt=False");
//});


var app = builder.Build();



// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
